#' @keywords internal
"_PACKAGE"