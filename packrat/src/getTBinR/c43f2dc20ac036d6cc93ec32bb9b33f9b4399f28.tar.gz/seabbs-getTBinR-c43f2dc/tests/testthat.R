library(testthat)
library(getTBinR)

test_check("getTBinR")
