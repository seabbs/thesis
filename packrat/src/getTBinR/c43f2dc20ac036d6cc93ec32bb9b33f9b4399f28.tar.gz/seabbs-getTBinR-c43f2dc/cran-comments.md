
## Test environments

* local OS X install, R 3.5.2
* ubuntu 12.04 (on travis-ci), R 3.5.2
* win-builder (devel and release)

## Comment

* Fixed external link (dashboard that required updating).

## R CMD check results

0 errors | 0 warnings | 0 note


## Reverse dependencies

There are no reverse dependencies.

