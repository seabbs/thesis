#' \packageDescription{koRpus}
#'
#' The DESCRIPTION file:
#' \tabular{ll}{
#' Package: \tab koRpus\cr
#' Type: \tab Package\cr
#' Version: \tab 0.11-5\cr
#' Date: \tab 2018-10-27\cr
#' Depends: \tab R (>= 3.0.0),sylly (>= 0.1-4)\cr
#' Enhances: \tab rkward\cr
#' Encoding: \tab UTF-8\cr
#' License: \tab GPL (>= 3)\cr
#' LazyLoad: \tab yes\cr
#' URL: \tab https://reaktanz.de/?c=hacking&s=koRpus\cr
#' }
#'
#' @title
#' \packageTitle{koRpus}
#' @author
#' \packageAuthor{koRpus}
#'
#' Maintainer: \packageMaintainer{koRpus}
"_PACKAGE"
