## Test environments
* local macOS install (10.14.1), R 3.5.2
* local linux install (Ubuntu 18.04), R 3.5.2
* macOS and Linux on travis-ci

## R CMD check results
There were no ERRORs or WARNINGs. There was a NOTE about potential mis-spellings of LibBi and RBi. These are software packages and spelled correctly.

## Downstream dependencies
0 packages with problems.

## Static vignette
A vignette is included, built locally using R.rsp as it depends on external software (LibBi) listed in the SystemRequirements.
