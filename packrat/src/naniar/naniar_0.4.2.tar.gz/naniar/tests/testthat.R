library(testthat)
library(naniar)

test_check("naniar")
