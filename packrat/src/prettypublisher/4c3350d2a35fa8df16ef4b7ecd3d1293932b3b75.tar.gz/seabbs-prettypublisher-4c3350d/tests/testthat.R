library(testthat)
library(prettypublisher)

test_check("prettypublisher")
