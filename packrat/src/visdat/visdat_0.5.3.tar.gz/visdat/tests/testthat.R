library(testthat)
library(visdat)

test_check("visdat")
