library(testthat)
library(socialmixr)

test_check("socialmixr")
