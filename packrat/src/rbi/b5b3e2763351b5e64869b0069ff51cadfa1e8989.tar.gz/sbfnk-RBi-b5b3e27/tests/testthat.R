library(testthat)
library(rbi)

test_check("rbi")
