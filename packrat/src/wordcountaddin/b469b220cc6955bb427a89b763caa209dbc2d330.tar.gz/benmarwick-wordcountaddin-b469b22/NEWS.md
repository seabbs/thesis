# wordcountaddin 0.3.0

NEW FEATURES

* Count words from Rmd filename and get scalar as output (#20)

MINOR IMPROVEMENTS

* make the functions more DRY by adding some unexported fns
* Expanded readme slightly
* Added more tests

# wordcountaddin 0.2.0

NEW FEATURES

* Count words from Rmd filename without using RStudio (#3)
* Count words in active Rmd in RStudio without making text selection (#3)
* Count words in character string from command line (without Rmd or RStudio) (#2)

MINOR IMPROVEMENTS

* Added a `NEWS.md` file to track changes to the package.
* Expanded readme
* Added more tests

BUG FIXES

* Fixed inaccurate count when <br> present (#1)

DEPRECATED AND DEFUNCT

NA

# wordcountaddin 0.1.0

Initial release


