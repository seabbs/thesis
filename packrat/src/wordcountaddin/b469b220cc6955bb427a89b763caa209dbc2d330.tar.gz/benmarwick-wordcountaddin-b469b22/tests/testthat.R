library(testthat)
library(wordcountaddin)

test_check("wordcountaddin")
