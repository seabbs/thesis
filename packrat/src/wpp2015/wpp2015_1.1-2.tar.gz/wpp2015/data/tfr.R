tfr <- read.delim(file='tfr.txt', comment.char='#', check.names=FALSE)

