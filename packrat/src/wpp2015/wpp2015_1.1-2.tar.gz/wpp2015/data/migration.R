migration <- read.delim(file='migration.txt', comment.char='#', check.names=FALSE)
