e0Mproj80u <- read.delim(file='e0Mproj80u.txt', comment.char='#', check.names=FALSE)
