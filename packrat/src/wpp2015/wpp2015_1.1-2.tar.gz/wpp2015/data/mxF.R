mxF <- read.delim(file='mxF.txt', comment.char='#', check.names=FALSE)
