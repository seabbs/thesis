tfrprojMed <- read.delim(file='tfrprojMed.txt', comment.char='#', check.names=FALSE)

