e0Fproj <- read.delim(file='e0Fproj.txt', comment.char='#', check.names=FALSE)
