e0F <- read.delim(file='e0F.txt', comment.char='#', check.names=FALSE)
