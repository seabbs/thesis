mxM <- read.delim(file='mxM.txt', comment.char='#', check.names=FALSE)
