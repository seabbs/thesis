e0F_supplemental <- read.delim(file='e0F_supplemental.txt', comment.char='#', check.names=FALSE)
