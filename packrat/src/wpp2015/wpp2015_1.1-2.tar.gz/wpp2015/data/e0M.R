e0M <- read.delim(file='e0M.txt', comment.char='#', check.names=FALSE)

