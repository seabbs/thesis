e0Fproj80l <- read.delim(file='e0Fproj80l.txt', comment.char='#', check.names=FALSE)
