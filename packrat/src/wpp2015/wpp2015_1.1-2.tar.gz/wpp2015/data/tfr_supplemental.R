tfr_supplemental <- read.delim(file='tfr_supplemental.txt', comment.char='#', check.names=FALSE)

