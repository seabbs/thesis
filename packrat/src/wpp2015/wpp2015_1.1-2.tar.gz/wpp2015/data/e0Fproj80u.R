e0Fproj80u <- read.delim(file='e0Fproj80u.txt', comment.char='#', check.names=FALSE)
