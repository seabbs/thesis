tfrproj80l <- read.delim(file='tfrproj80l.txt', comment.char='#', check.names=FALSE)

