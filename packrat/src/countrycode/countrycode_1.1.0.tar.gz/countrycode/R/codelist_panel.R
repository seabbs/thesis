#' Country Code Translation Data Frame (Country-Year Panel)
#'
#' A panel of country-year observations with various codes
#'
#' @docType data
#' @keywords datasets
#' @name codelist_panel
#' @usage codelist_panel
#' @format data frame with codes as columns
NULL
